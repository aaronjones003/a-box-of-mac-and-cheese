import json
import random
import boto3
import base64
# from PIL import Image, ImageDraw, ImageFont



def lambda_handler(event, context):
    s3_client = boto3.client('s3')

    body = event.get('body')

    background_object = s3_client.get_object(Bucket=body.get('bucket'), Key=body.get('background_key'))

    background_image_base64 = json.loads(background_object.get('Body').read()).get('images')[0]


    s3_client.put_object(Body=base64.b64decode(background_image_base64), Bucket=body.get('bucket'), Key='testout')

    # s3_client

    response_body = json.loads(response["body"].read())
    base64_image_data = response_body["images"][0]

    # Get image bytes from response
    image_bytes = response['generatedImage']

    # Create Pillow Image object
    image = Image.open(io.BytesIO(image_bytes))

    # Overlay title on image
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype("arial.ttf", 48)  # Choose appropriate font and size
    text_width, text_height = draw.textsize(title, font=font)
    position = ((image.width - text_width) // 2, (image.height - text_height) // 2)
    draw.text(position, title, font=font, fill=(255, 255, 255))  # White text

    # Save image to S3
    s3_client = boto3.client('s3')
    bucket_name = "a-box-of-mac-and-cheese-images"  # Replace with your S3 bucket name
    file_key = f"covers/{title}.png"
    # img_byte_arr = io.BytesIO()
    # image.save(img_byte_arr, format='PNG')
    # img_byte_arr = img_byte_arr.getvalue()
    s3_client.put_object(Body=base64.b64decode(base64_image_data), Bucket=bucket_name, Key=file_key)

    # Return image URL
    image_url = f"https://{bucket_name}.s3.amazonaws.com/{file_key.replace(' ', '+')}"
    return image_url

    return {
        'statusCode': 200,
        'body': {
            'title': title,
            'author': author,
            'titan_params': {
                "taskType": "TEXT_IMAGE",
                "textToImageParams": {"text": f"A fantasy background image with a theme of {title} with NO text"},
                "imageGenerationConfig": {
                    "numberOfImages": 1,
                    "quality": "standard",
                    "cfgScale": 8.0,
                    "height": 640,
                    "width": 384,
                    "seed": 0,
                },
            },
            'background_object': f"s3://{bucket_name}/{background_key.replace(' ', '+')}",
            'cover_object': f"s3://{bucket_name}/{cover_key.replace(' ', '+')}",
            'output_url': output_url,
        }
    }